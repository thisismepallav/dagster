import dagster as dg

defs = dg.Definitions(
    resources={},
)
